<?php
    // Class Tích Hợp Gạch Thẻ TrumCard.Vn

Class TrumCard {

    public $api_key;
    public $card_type;
    public $card_seri;
    public $card_code;
    public $card_amount;
    public $callback;
    public $requestid;

    public function _postdata() {
            $api = 'https://trumcard.vn/Card_Exchange?key='.$this->api_key.'&card_type='.$this->card_type.'&card_code='.$this->card_code.'&card_seri='.$this->card_seri.'&card_amount='.$this->card_amount.'&callback='.$this->callback.'&request_id='.$this->requestid;
            $ch = curl_init($api);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER["HTTP_USER_AGENT"]);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $res = curl_exec($ch);
            curl_close($ch);
            return $res;
    }
}
