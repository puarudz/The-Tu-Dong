<?php
/****

Giá trị trumcard gửi lại theo phương thức GET:

status: mã lỗi khi xử lý thẻ
pricesvalue: Mệnh giá đối tác gửi lên
value_receive: Mệnh giá đúng của thẻ
card_code: Mã thẻ cào đã gửi lên
card_seri: Seri thẻ cào đã gửi lên
requestid: Mã đơn hàng của đối tác gửi lên


Lưu Ý: Để phân biệt thẻ đúng và thẻ sai mệnh giá quý khách vui lòng so sánh mệnh giá gửi lên là pricesvalue và giá trị đúng của thẻ là value_receive.

***/

// lưu lại giá trị callback vào log.txt
$myfile = fopen("log.txt", "a");
$txt = $_GET['status']."|".number_format($_GET['value_receive'])."|".$_GET['pricesvalue']."|".$_GET['card_code']."|".$_GET['card_seri']."|".$_GET['requestid']."|".date('H:i:s d/m/y', time())."\n";
fwrite($myfile, $txt);
fclose($myfile);



if($_GET['status']) {

	if($_GET['status'] == 200) {

		// thẻ đúng 

	}else if($_GET['status'] == 201) {

		// thẻ đúng nhưng sai định dạng

	}else if($_GET['status'] == 100) {

		// thẻ sai

	}else {

		echo 'lỗi';

	}

}