<?php
    require 'Class.TrumCard.php'; // require class

    $trumcard = new TrumCard;
    $trumcard->api_key = 'api_key'; // là api tích hợp lấy bên trumcard.vn
    $trumcard->card_type = 'VIETTEL'; // là tên nhà mạng, lưu ý viết hoa
    $trumcard->card_seri = '10000056423156';  // Mã Seri Thẻ 
    $trumcard->card_code = '5935611123551'; // Mã Thẻ
    $trumcard->card_amount = '20000'; // Mệnh Giá Thẻ
    $trumcard->callback = 'https://domaincuaban.com/callback.php'; // là url trumcard sẽ gửi lại thông tin sau khi xử lý thẻ cho bạn
    $trumcard->requestid = rand(100000, 999999);  // Mã order của bạn, nó là duy nhất (enique) để phân biệt giao dịch.

    $post = json_decode($trumcard->_postdata(), true);

    if ($post['status'] == 200) {
        // thẻ gửi lên thành công
    }else if($post['status'] == 401){
        // Định dạng thẻ không đúng!
    }else if($post['status'] == 400){
        // Thẻ đã tồn tại trên hệ thống!
    }else if($post['status'] == 100){
        // nhập thiếu dữ liệu
    }else {
        echo $post['message'];
        // lỗi khác
    }